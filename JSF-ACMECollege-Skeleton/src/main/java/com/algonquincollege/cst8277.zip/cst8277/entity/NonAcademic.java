/********************************************************************************************************
 * File:  NonAcademicClub.java Course materials CST 8277
 *
 * @author Teddy Yap
 * @author Shariar (Shawn) Emami
 * 
 */
package com.algonquincollege.cst8277.entity;

import java.io.Serializable;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

// TODO NA01 - Add missing annotations, please see lecture slides.  Value 1 is academic and value 0 is non-academic.
@Entity
// DiscriminatorValue tells JPA that when academic column = 0, instantiate this class
@DiscriminatorValue("0")
public class NonAcademic extends StudentClub implements Serializable {
	private static final long serialVersionUID = 1L;

	public NonAcademic() {
		super(false);
	}
}